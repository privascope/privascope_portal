#!/bin/bash

>&2 echo "Goodbye, cruel world!"

exit 23
