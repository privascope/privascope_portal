#!/bin/bash

env
