#!/bin/bash

curl 104.40.211.35 --max-time 3 # Microsoft.com
curl 98.137.246.8 --max-time 3 # Yahoo.com
curl microsoft.com --max-time 3
curl yahoo.com --max-time 3
