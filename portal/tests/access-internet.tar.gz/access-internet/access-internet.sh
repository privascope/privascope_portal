#!/bin/bash

curl http://www.example.com --max-time 3
curl 93.184.216.34 --max-time 3